<?php
	define('DB_SERVER', '198.71.225.57');
        define('DB_USERNAME', 'lauren');
        define('DB_PASSWORD', 'justin@02');
        define('DB_DATABASE', 'hurricane');
	
	$con=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
	
	if(!$con){
		echo "Could not connect to database";
		}
//"require": {  "google/apiclient": "1.0.*@beta"; }
//set_include_path(get_include_path() . PATH_SEPARATOR . '/path/to/google-api-php-client/src');

?>
